drop table if exists awz_agelimit_role;
drop table if exists awz_agelimit_role_relation;
drop table if exists awz_agelimit_permission;