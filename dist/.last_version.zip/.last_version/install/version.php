<?
$arModuleVersion = array(
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2024-10-23 12:37:00"
);
?>