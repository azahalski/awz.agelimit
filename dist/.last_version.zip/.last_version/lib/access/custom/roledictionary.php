<?php
namespace Awz\Agelimit\Access\Custom;

use Awz\Agelimit\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}